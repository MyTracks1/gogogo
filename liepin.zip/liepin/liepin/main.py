from scrapy import cmdline
cmdline.execute('scrapy crawl lie_pin'.split())